--
-- 資料庫： `event_profile`
--

-- --------------------------------------------------------

--
-- 資料表結構 `active`
--

CREATE TABLE `active` (
  `id` int(11) NOT NULL,
  `name` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `introduction` text COLLATE utf8_unicode_ci NOT NULL,
  `date` date NOT NULL,
  `time` varchar(11) COLLATE utf8_unicode_ci NOT NULL,
  `place` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `amount` int(10) NOT NULL,
  `participate` text COLLATE utf8_unicode_ci NOT NULL,
  `link` text COLLATE utf8_unicode_ci NOT NULL,
  `host` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `tag` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `image` varchar(100) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- 資料表的匯出資料 `active`
--

INSERT INTO `active` (`id`, `name`, `introduction`, `date`, `time`, `place`, `amount`, `participate`, `link`, `host`, `tag`, `image`) VALUES
(8, '精誠之夜', '►► 2016 台科大精誠之夜 Starry night ◄◄\r\n\r\n▇ 第九屆．精誠之夜 ▇\r\n\r\n精誠之夜的第一手資訊，\r\n都將由此粉絲專業發佈。\r\n最後成果將在5/21(六)，\r\n一覽無遺地呈現在大家面前。\r\n\r\n◆ 總召\r\n黃建霖 0989-869-715\r\n鄭宇婷 0963-679-791', '2016-05-21', '17:30-21:30', 'RB-105', 500, '不限', 'https://www.facebook.com/2016.NTUST.StarryNight', 'another', '#精誠之夜high翻天', '13125010_1735686049980187_3873229803793878766_n.jpg'),
(9, '逐夢資旅', '2016 國立臺灣科技大學 第三屆 資訊工程營\r\n\r\n《 活動資訊 》\r\n\r\n活動對象：全國高中職學生\r\n活動地點：國立臺灣科技大學\r\n活動時間：2016/07/09 ~ 2016/07/12\r\n【四天三夜，含住宿(本校宿舍)】\r\n\r\n《 報名資訊及文件》\r\n\r\n報名時間：2016/04/11 ~ 2016/05/31\r\n報名費用：3799 \r\n早鳥優惠價：3499 (於04/11 ~ 05/02期間報名)\r\n低收入戶補助價(兩名)：2200\r\n\r\n報名流程 : https://goo.gl/vuvEyD\r\n線上報名 : http://goo.gl/forms/l71qykOtSu\r\n下載報名表 : https://goo.gl/LuBlny\r\n報名表範例 : https://goo.gl/cTh1VG\r\n家長同意書 : https://goo.gl/lKHYdx\r\n\r\n《 聯絡方式 》\r\n\r\nntust.csie.camp@gmail.com', '2016-07-09', '8:00-18:00', '國立臺灣科技大學', 100, '全國高中職學生', 'https://www.facebook.com/NTUST.CSIE.camp.2016', 'another', '#逐夢資旅', '12985530_196676267382373_5542115269791758107_n.jpg'),
(10, '琉心細語', '那些，我們說不出口的心意，\r\n就像宇宙中載浮載沉的碎片。\r\n如果有一天，我們勇敢的傳達出去了，\r\n它，將會化為流星，\r\n降落在對方心中。\r\n你，有成為流星的勇氣嗎？\r\n\r\n琉璃，自古以來以清澈無暇的外表，代表著單純與真誠的心。將其贈與朋友，表示自己對朋友的真誠無私的心;將其贈與情人，表示對情人堅貞不二的愛。\r\n新竹以出產華麗優美的琉璃工藝品而出名，借由這次「琉心細語」活動，一方面宣揚新竹特產琉璃工藝品外，另一方面也將自古以來琉璃所象徵的傳統意義與情操傳承下去。', '2015-10-01', '8:00-17:00', '國立臺灣科技大學', 0, '不限', 'https://www.facebook.com/2015ntusthischuglass', 'club', '#台科竹友-琉心細語', '12042806_1643644219241030_5898009274330203966_n.jpg'),
(11, '2016 吉吉復吉祭', '2016 三校聯展 吉吉復吉祭\r\n\r\n第一屆三校音樂聯展\r\n由台灣大學、台灣科技大學、台灣師範大學的吉他社共同舉辦\r\n\r\n3/20（日）在台灣師範大學水平方\r\n13:00-16:00\r\n除了有fullband與acoustic表演之外\r\n還有賣食物、小遊戲與二手市集\r\n\r\n歡迎喜愛音樂喜愛交朋友的你來跟我們嗨翻整個下午！', '2016-03-20', '8:00-17:00', '台北市大安區和平東路一段162號', 300, '台大吉他社 師大吉他社 台科絃韻吉他', 'https://www.facebook.com/gigifugigi/', 'club', '#2016 吉吉復吉祭-三校音樂節 台大', '12715392_537370349757188_2813206901121704574_n.jpg'),
(12, '搖滾實驗室期末成發', '搖滾實驗室期中成發___台上見。\r\n時間: 6/24(五) 18:00 準時開始\r\n地點: TR一樓廣場\r\n等待你的到來', '2016-06-24', '18:00-21:00', 'TR一樓廣場', 500, '不限', 'https://www.facebook.com/events/564458980414855/', 'club', '#期末成發', '1170796_619733311404454_493841293_n.jpg'),
(13, '『Mask螢色瘋暴』', '當黑夜降臨\r\n面具背後的那個人\r\n他，還是你原本認識的他嗎\r\n今夜，\r\n釋放你內心的壓抑\r\n今夜，\r\n解放你原始的野性\r\n今夜，\r\n拋開一切享受Mask螢色瘋暴\r\n這次，將帶給你前所未見的聖誕夜\r\n\r\n開放外系、外校參加\r\n➡️已繳系費者 $100\r\n➡️未繳系費/外系/外校 $450\r\n➡️前200位透過按讚分享活動有特別優惠 $390\r\n➡️自備最亮眼的面具入場\r\n➡️vip包廂(專屬的開放式包廂備有舒適的沙發專屬觀賞表演的位置另外贈送美味拼盤及啤酒）\r\nLuxury party house(建議14人以上)：$2000\r\nMystery fun house (建議10人以上）：$1600\r\nFancy dream house(建議8人以上)：$1200\r\nFashion mini house(建議5人以下)：$600\r\n\r\n➡️現場備有酒水加上軟性飲料任你暢飲！並準備精緻的小點心給你享用\r\n另外還有豐富的獎品等著你來帶走\r\n\r\n⁉️⁉️若有確定購買包廂請先私訊粉專，數量有限售完為止，門票開賣時間請持續關注活動頁面\r\n\r\n\r\n更多更精采的活動請關注 → "活動網址\r\nhttps://www.facebook.com/events/177881272560677/\r\n', '2015-12-25', '18:15', '信義區松德路171號B1, Taipei', 0, '不限', 'https://www.facebook.com/events/177881272560677/', 'another', '#Mask螢色瘋暴', '11203047_979888855390179_4562894084433842227_n.jpg');

-- --------------------------------------------------------

--
-- 資料表結構 `member`
--

CREATE TABLE `member` (
  `id` int(10) NOT NULL,
  `user` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(10) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- 資料表的匯出資料 `member`
--

INSERT INTO `member` (`id`, `user`, `password`) VALUES
(1, 'admin', '1234');

--
-- 已匯出資料表的索引
--

--
-- 資料表索引 `active`
--
ALTER TABLE `active`
  ADD PRIMARY KEY (`id`);

--
-- 資料表索引 `member`
--
ALTER TABLE `member`
  ADD PRIMARY KEY (`id`);

--
-- 在匯出的資料表使用 AUTO_INCREMENT
--

--
-- 使用資料表 AUTO_INCREMENT `active`
--
ALTER TABLE `active`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- 使用資料表 AUTO_INCREMENT `member`
--
ALTER TABLE `member`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
